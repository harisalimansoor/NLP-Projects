# -*- coding: utf-8 -*-
"""
Created on Thu Jun  4 13:31:17 2020

@author: haris
"""


import numpy as np
import pandas as pd

path="C:/Users/haris/Google Drive/machine learning projects/kid name generator/"

import csv

boy_names=[]
girl_names=[]

file=open( path + "babynames_clean.CSV", "r")
reader = csv.reader(file)
for idx, line in enumerate(reader):

    #t=line[0],line[1]
    if line[1]=="boy":
        boy_names.append(line[0])
        
    if line[1]=="girl":
        girl_names.append(line[0])
    #print(t)
    
    #if idx==5:
     #   break

#%%
        
with open(path+"boy_names.txt", 'w') as f:
    f.write("\n".join(map(str, boy_names)))

with open(path+"girl_names.txt", 'w') as f:
    f.write("\n".join(map(str, girl_names)))


#%% process name files
    
import glob
txt_files = glob.glob("test/*.txt")



    
    